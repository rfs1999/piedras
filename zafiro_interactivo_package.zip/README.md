# Zafiro Cornflower Interactivo

Esta es una herramienta interactiva en HTML para estimar el precio, peso y profundidad de un zafiro tipo Cornflower Blue según características seleccionadas:

- Claridad (I2 a IF)
- Tratamiento (calor, difusión, etc.)
- Calidad de corte
- Vivacidad de color
- Origen
- Naturaleza (natural o sintético)
- Dimensiones

## Cómo usar

1. Abre el archivo `zafiro_interactivo.html` en cualquier navegador web.
2. Selecciona las opciones desde los menús desplegables.
3. Se calcularán automáticamente:
   - Profundidad estimada
   - Peso estimado
   - Precio por quilate (rango)
   - Precio total estimado (rango)

## Licencia

Uso personal o educativo permitido. Requiere permiso para uso comercial.